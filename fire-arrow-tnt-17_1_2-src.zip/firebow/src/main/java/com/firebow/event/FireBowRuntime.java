package com.firebow.event;

import com.firebow.util.*;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Runtime v17 — HT1-speed cart placement:
 *
 * RAIL: 2-tick Grim-safe (rotation → movement packet → interact)
 * CART: direct same-tick as rail-confirm, no rotation delay
 *
 * Timing so sánh:
 *   v16:  rail(tick 0) → cart(tick 2–4) = ~100–200ms delay
 *   v17:  rail(tick 0) → cart(tick 1)   = ~50ms delay = HT1 speed
 *
 * Tick 0: scheduleRailPlacement() → prepareRailPlacement() → rotation pending
 * Tick 0: beforeSync() → applyBeforeSync() → movement packet mang rotation
 * Tick 1: onClientTick() → executePending() → rail interactBlock
 *         → NGAY LẬP TỨC processPendingCarts() → placeCartDirect() nếu rail confirmed
 *
 * Cart delay = 1 tick (đủ để server nhận rail packet, với retry nếu chưa confirm).
 */
public final class FireBowRuntime {

    private static final FireBowRuntime INSTANCE = new FireBowRuntime();
    public static FireBowRuntime get() { return INSTANCE; }

    // Dedup entity
    private final Map<Integer, Long> acceptedArrows = new ConcurrentHashMap<>();
    private static final long ARROW_TTL = 3000L;

    // Dedup position
    private final Set<BlockPos> recentDone =
        Collections.newSetFromMap(new ConcurrentHashMap<>());

    // Pending carts: pos → [ticksLeft, retries]
    private final Map<BlockPos, int[]> pendingCarts = new ConcurrentHashMap<>();
    private static final int MAX_RETRY = 10;

    // Rail placement phase
    private volatile boolean railPrepared = false;

    // Bow release precomputed
    private volatile BlockPos precomputedRailPos = null;
    private volatile long     precomputedAtMs    = 0L;
    private static final long PRECOMPUTED_TTL_MS = 2000L;

    private volatile boolean enabled = true;

    private FireBowRuntime() {}

    public boolean isEnabled() { return enabled; }
    public void    toggle()    { enabled = !enabled; }

    // ─── Precomputed ─────────────────────────────────────────────────────────

    public void storePrecomputedPos(BlockPos pos) {
        precomputedRailPos = pos;
        precomputedAtMs    = System.currentTimeMillis();
    }

    public BlockPos getAndClearPrecomputed() {
        BlockPos pos = precomputedRailPos;
        if (pos == null) return null;
        if (System.currentTimeMillis() - precomputedAtMs > PRECOMPUTED_TTL_MS) {
            precomputedRailPos = null;
            return null;
        }
        precomputedRailPos = null;
        return pos;
    }

    // ─── Dedup ───────────────────────────────────────────────────────────────

    public boolean isDuplicateArrow(int id) {
        Long t = acceptedArrows.get(id);
        return t != null && (System.currentTimeMillis() - t) < ARROW_TTL;
    }

    public boolean wasRecentlyPlaced(BlockPos pos) {
        return recentDone.contains(pos);
    }

    // ─── Phase 1: Arrow tick → schedule rail ────────────────────────────────

    public void scheduleRailPlacement(MinecraftClient mc, int arrowId,
                                      BlockPos railPos, int railSlot) {
        if (recentDone.contains(railPos)) return;
        if (railPrepared || InteractionUtil.hasPending()) return;

        InteractionUtil.prepareRailPlacement(mc, railPos, railSlot);
        railPrepared = true;

        acceptedArrows.put(arrowId, System.currentTimeMillis());
        recentDone.add(railPos);

        AsyncRunner.runDelayed(() -> {
            acceptedArrows.remove(arrowId);
            recentDone.remove(railPos);
        }, ARROW_TTL);
    }

    // ─── Phase 2: beforeSync → apply rotation ───────────────────────────────

    public void beforeSync() {
        if (!enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (mc.player.isUsingItem()) return;
        RotationUtil.applyBeforeSync(mc.player);
    }

    // ─── Phase 3: onClientTick → execute ────────────────────────────────────

    /**
     * Gọi DUY NHẤT từ FireBowClient.
     */
    public void onClientTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;
        if (!enabled) {
            InteractionUtil.clearPending();
            pendingCarts.clear();
            railPrepared = false;
            return;
        }
        if (mc.player.isUsingItem()) return;

        // Execute pending rail (tick sau phase 1)
        if (railPrepared && InteractionUtil.hasPending()) {
            InteractionUtil.executePending(mc);
            railPrepared = false;
            // Không return — ngay sau đó process carts cùng tick này
        }

        processPendingCarts(mc);
    }

    /**
     * Cart: direct same-tick, 1-tick delay sau rail.
     *
     * Grim không strict-check rotation khi spawn entity (minecart)
     * lên rail đã tồn tại. Direct interact là safe và khớp với
     * timing của HT1 player thật (rail → cart trong cùng 1 lần nhìn xuống).
     */
    private void processPendingCarts(MinecraftClient mc) {
        if (pendingCarts.isEmpty()) return;

        Iterator<Map.Entry<BlockPos, int[]>> iter = pendingCarts.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry<BlockPos, int[]> e = iter.next();
            BlockPos pos   = e.getKey();
            int[]    state = e.getValue(); // [ticksLeft, retries]

            state[0]--;
            if (state[0] > 0) continue;

            boolean hasRail =
                mc.world.getBlockState(pos).isOf(Blocks.RAIL) ||
                mc.world.getBlockState(pos).isOf(Blocks.POWERED_RAIL);

            if (hasRail) {
                iter.remove();
                SearchResult cart = InventoryUtil.findItem(Items.TNT_MINECART);
                if (!cart.isMissing()) {
                    // Direct — không cần 2-tick, không cần beforeSync
                    InteractionUtil.placeCartDirect(mc, pos, cart.slot);
                }
                return;
            } else if (state[1] < MAX_RETRY) {
                state[0] = 1;
                state[1]++;
            } else {
                iter.remove();
            }
        }
    }

    /**
     * Schedule cart.
     * delay = 1 tick base. Với ping cao → tăng thêm 1-2 tick.
     * Minimum 1 tick — không thể 0 vì server cần nhận rail packet trước.
     */
    public void scheduleCartPlacement(BlockPos railPos, long pingMs) {
        // 1 tick (50ms) đủ với ping tốt.
        // Với ping cao rail có thể chưa confirm → retry handle phần còn lại.
        int delay = pingMs > 250 ? 2 : 1;
        pendingCarts.put(railPos, new int[]{ delay, 0 });
    }
}
